package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.data.db.AppDatabase
import com.example.data.repository.RouteRepository
import com.example.ui.RouteViewModel
import com.example.ui.RouteViewModelFactory
import com.example.ui.Screen
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.MapScreen
import com.example.ui.theme.MyApplicationTheme

/**
 * Actividad Principal que inicializa la capa de base de datos local (Room) y sirve de contenedor
 * de navegación reactiva bajo Compose.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Habilitar diseño de dibujo de borde a borde (Edge-to-Edge)
        enableEdgeToEdge()

        // Inicialización manual de la base de datos y repositorios para inyección directa sin sobrecarga
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = RouteRepository(database.routeDao())

        // Inicializar ViewModel utilizando el factory personalizado
        val viewModel = ViewModelProvider(
            this,
            RouteViewModelFactory(repository)
        )[RouteViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainContainer(viewModel = viewModel)
            }
        }
    }
}

/**
 * Contenedor Maestro de la Interfaz.
 * Ofrece la barra de navegación integrada Material 3 con active-pills y transiciona orgánicamente las pantallas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainer(viewModel: RouteViewModel) {
    val currentScreen = viewModel.currentScreen

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentScreen !is Screen.Detail) {
                Column {
                    TopAppBar(
                        title = {
                            Text(
                                text = "Localizador",
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = {}) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menú",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        actions = {
                            // GPS Quality Tracker status capsule from design HTML spec
                            Surface(
                                shape = RoundedCornerShape(percent = 50),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    val isTrackingActive by viewModel.isTrackingLive.collectAsState()
                                    Icon(
                                        imageVector = if (isTrackingActive) Icons.Default.GpsFixed else Icons.Default.GpsOff,
                                        contentDescription = null,
                                        tint = if (isTrackingActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = if (isTrackingActive) "PRECISIÓN: 3M" else "GPS ACTIVO",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isTrackingActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            IconButton(onClick = {}) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Más opciones",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        thickness = 1.dp
                    )
                }
            }
        },
        bottomBar = {
            // Ocultamos la barra de navegación si el usuario se encuentra visualizando el detalle de un mapa estático
            if (currentScreen !is Screen.Detail) {
                Column {
                    val isTrackingActive by viewModel.isTrackingLive.collectAsState()
                    if (isTrackingActive) {
                        // Foreground Service Active Notification Simulation bar from Design HTML
                        Surface(
                            color = Color(0xFF21005D),
                            contentColor = Color.White
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationSearching,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Servicio activo • Grabando recorrido...",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Text(
                                    text = "0.3 MB",
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    NavigationBar {
                        // Item 1: Mapa / Localizador en tiempo real
                        NavigationBarItem(
                            selected = currentScreen is Screen.Tracking,
                            onClick = { viewModel.navigateTo(Screen.Tracking) },
                            icon = {
                                Icon(
                                    imageVector = if (currentScreen is Screen.Tracking) Icons.Filled.Map else Icons.Outlined.Map,
                                    contentDescription = "Localizador en Vivo"
                                )
                            },
                            label = { Text("Localizar", fontWeight = FontWeight.SemiBold) }
                        )

                        // Item 2: Historial de rutas
                        NavigationBarItem(
                            selected = currentScreen is Screen.History,
                            onClick = { viewModel.navigateTo(Screen.History) },
                            icon = {
                                Icon(
                                    imageVector = if (currentScreen is Screen.History) Icons.Filled.History else Icons.Outlined.History,
                                    contentDescription = "Historial de Rutas"
                                )
                            },
                            label = { Text("Historial", fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        // Carga dinámicamente el composable correspondiente inyectando insets correctos de Scaffold
        val contentModifier = Modifier.padding(innerPadding)

        when (val screen = currentScreen) {
            is Screen.Tracking -> {
                MapScreen(
                    viewModel = viewModel,
                    modifier = contentModifier
                )
            }
            is Screen.History -> {
                HistoryScreen(
                    viewModel = viewModel,
                    modifier = contentModifier
                )
            }
            is Screen.Detail -> {
                // Detalle no tiene padding del Scaffold botomBar para optimizar el mapa al 100%
                DetailScreen(
                    viewModel = viewModel,
                    routeId = screen.routeId,
                    modifier = Modifier
                )
            }
        }
    }
}

/**
 * Componible auxiliar para compatibilidad de pruebas de compilación y capturas.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
