package com.example.location

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.db.AppDatabase
import com.example.data.repository.RouteRepository
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.TimeUnit

/**
 * Servicio en primer plano (Foreground Service) que gestiona el seguimiento GPS en tiempo real.
 * Diseñado con persistencia interna reactiva (Room) y variables estáticas observables en Compose.
 */
class LocationService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var repository: RouteRepository

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    private var activeRouteId: Int = -1
    private var totalDistanceMeters: Double = 0.0
    private var lastRecordedLocation: Location? = null

    private var timerJob: Job? = null
    private var startTimeMillis: Long = 0L

    companion object {
        private const val TAG = "LocationService"
        private const val CHANNEL_ID = "location_tracking_channel"
        private const val NOTIFICATION_ID = 1205

        // Acciones de control del servicio
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_PAUSE = "ACTION_PAUSE"

        // Claves para Intent
        const val EXTRA_ROUTE_NAME = "EXTRA_ROUTE_NAME"
        const val EXTRA_ROUTE_ID = "EXTRA_ROUTE_ID"

        // Estado global expuesto en tiempo real para Compose
        private val _isTracking = MutableStateFlow(false)
        val isTracking = _isTracking.asStateFlow()

        private val _currentRouteId = MutableStateFlow<Int?>(null)
        val currentRouteId = _currentRouteId.asStateFlow()

        private val _latestLocation = MutableStateFlow<Location?>(null)
        val latestLocation = _latestLocation.asStateFlow()

        private val _elapsedTimeSeconds = MutableStateFlow(0L)
        val elapsedTimeSeconds = _elapsedTimeSeconds.asStateFlow()

        private val _currentDistanceMeters = MutableStateFlow(0.0)
        val currentDistanceMeters = _currentDistanceMeters.asStateFlow()
    }

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getDatabase(applicationContext)
        repository = RouteRepository(database.routeDao())

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Configuración del callback para actualizaciones GPS de FusedLocationProviderClient
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                super.onLocationResult(result)
                result.locations.forEach { location ->
                    processNewLocation(location)
                }
            }
        }

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        Log.d(TAG, "onStartCommand acción recibida: $action")

        when (action) {
            ACTION_START -> {
                val routeName = intent.getStringExtra(EXTRA_ROUTE_NAME) ?: "Ruta sin nombre"
                val routeId = intent.getIntExtra(EXTRA_ROUTE_ID, -1)
                startTracking(routeName, routeId)
            }
            ACTION_PAUSE -> {
                pauseTracking()
            }
            ACTION_STOP -> {
                stopTracking()
            }
        }

        return START_NOT_STICKY
    }

    private fun startTracking(routeName: String, routeId: Int) {
        if (_isTracking.value) return // Ya está en marcha

        _isTracking.value = true
        activeRouteId = routeId
        _currentRouteId.value = routeId

        // Iniciar en primer plano mostrando la notificación obligatoria
        val notification = buildNotification(routeName, "Calculando ubicación...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        serviceScope.launch {
            // Si la ruta ya existía, recuperamos su distancia histórica para continuar acumulando
            val existingRoute = repository.getRouteById(routeId)
            totalDistanceMeters = existingRoute?.distanceMeters ?: 0.0
            _currentDistanceMeters.value = totalDistanceMeters

            // Consultar las coordenadas previas para tener continuidad si es una reanudación
            val previousPoints = repository.getLocationPointsSync(routeId)
            if (previousPoints.isNotEmpty()) {
                val lastPoint = previousPoints.last()
                lastRecordedLocation = Location("gps").apply {
                    latitude = lastPoint.latitude
                    longitude = lastPoint.longitude
                    altitude = lastPoint.altitude
                }
            } else {
                lastRecordedLocation = null
            }

            requestLocationUpdates()
            startTimer()
        }
    }

    private fun requestLocationUpdates() {
        // Intervalos equilibrados para ahorrar batería y dar excelente precisión real
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            5000L // Intervalo de actualización: 5 segundos
        ).apply {
            setMinUpdateIntervalMillis(2000L) // Intervalo más rápido permisible: 2 segundos
            setMinUpdateDistanceMeters(2f)    // Desplazamiento mínimo indispensable para registrar: 2 metros
        }.build()

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        } catch (unlikely: SecurityException) {
            Log.e(TAG, "No se admiten permisos necesarios para iniciar updates de ubicación GPS: $unlikely")
            _isTracking.value = false
            stopSelf()
        }
    }

    private fun processNewLocation(location: Location) {
        if (location.accuracy > 40f) {
            // Ignorar ubicaciones con alta imprecisión (ruido GPS) para no degradar el recorrido
            return
        }

        _latestLocation.value = location

        serviceScope.launch {
            val routeId = activeRouteId
            if (routeId == -1) return@launch

            // Calcular distancia acumulada diferencial
            lastRecordedLocation?.let { last ->
                val distanceStep = last.distanceTo(location)
                // Filtrar saltos de ruido estático extremadamente pequeños o picos absurdos
                if (distanceStep > 1.5 && distanceStep < 300) {
                    totalDistanceMeters += distanceStep
                    _currentDistanceMeters.value = totalDistanceMeters

                    // Actualizar el valor consolidado de la distancia total en la entidad Route
                    val currentRoute = repository.getRouteById(routeId)
                    if (currentRoute != null) {
                        repository.updateRoute(currentRoute.copy(distanceMeters = totalDistanceMeters))
                    }
                }
            }

            lastRecordedLocation = location

            // Guardar punto GPS en base de datos local de manera asíncrona pero secuencial
            repository.addLocationPoint(
                routeId = routeId,
                latitude = location.latitude,
                longitude = location.longitude,
                altitude = location.altitude,
                speed = location.speed
            )

            // Actualizar notificación con estadísticas en vivo
            updateNotification(routeId)
        }
    }

    private fun updateNotification(routeId: Int) {
        serviceScope.launch {
            val route = repository.getRouteById(routeId) ?: return@launch
            val km = totalDistanceMeters / 1000.0
            val formattedDistance = String.format("%.2f km", km)
            val formattedTime = formatElapsedTime(_elapsedTimeSeconds.value)

            val contentText = "Distancia: $formattedDistance | Tiempo: $formattedTime"
            val notification = buildNotification(route.name, contentText)

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(NOTIFICATION_ID, notification)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        startTimeMillis = System.currentTimeMillis() - (_elapsedTimeSeconds.value * 1000L)
        timerJob = serviceScope.launch {
            while (isActive) {
                val elapsed = (System.currentTimeMillis() - startTimeMillis) / 1000L
                _elapsedTimeSeconds.value = elapsed
                delay(1000L)
            }
        }
    }

    private fun pauseTracking() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        timerJob?.cancel()
        _isTracking.value = false
    }

    private fun stopTracking() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        timerJob?.cancel()

        serviceScope.launch {
            if (activeRouteId != -1) {
                repository.stopActiveRoute(activeRouteId, totalDistanceMeters)
            }

            // Reiniciar estados una vez confirmado el guardado
            withContext(Dispatchers.Main) {
                _isTracking.value = false
                _currentRouteId.value = null
                _latestLocation.value = null
                _elapsedTimeSeconds.value = 0L
                _currentDistanceMeters.value = 0.0

                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, LocationService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Detener y Guardar",
                stopPendingIntent
            )
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true) // No molestar con vibraciones/sonidos molestos en cada actualización de metros
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Rastreo de Rutas GPS"
            val descriptionText = "Notificación persistente para el seguimiento de rutas en segundo plano"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun formatElapsedTime(seconds: Long): String {
        val hr = TimeUnit.SECONDS.toHours(seconds)
        val min = TimeUnit.SECONDS.toMinutes(seconds) % 60
        val sec = seconds % 60
        return String.format("%02d:%02d:%02d", hr, min, sec)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        timerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }
}
