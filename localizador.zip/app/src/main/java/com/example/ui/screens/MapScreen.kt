package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.LocationPoint
import com.example.data.model.Waypoint
import com.example.ui.RouteViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import kotlinx.coroutines.launch

/**
 * Pantalla principal del Mapa en Tiempo Real.
 * Ofrece controles para iniciar, pausar y detener la ruta, además de agregar Waypoints (Puntos de Interés).
 */
@Composable
fun MapScreen(
    viewModel: RouteViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Estado Observado del ViewModel
    val isTracking by viewModel.isTrackingLive.collectAsState()
    val activeRouteId by viewModel.activeRouteIdLive.collectAsState()
    val latestLocation by viewModel.latestLocationLive.collectAsState()
    val elapsedSeconds by viewModel.elapsedSecondsLive.collectAsState()
    val distanceMeters by viewModel.distanceMetersLive.collectAsState()
    val routePoints by viewModel.activeRoutePoints.collectAsState()
    val waypoints by viewModel.activeRouteWaypoints.collectAsState()

    // Control de diálogos de entrada
    var showStartDialog by remember { mutableStateOf(false) }
    var showWaypointDialog by remember { mutableStateOf(false) }
    var newRouteName by remember { mutableStateOf("") }
    var waypointName by remember { mutableStateOf("") }
    var waypointDescription by remember { mutableStateOf("") }

    // Manejo de permisos en tiempo de ejecución
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasLocationPermission = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
    }

    LaunchedEffect(Unit) {
        if (!hasLocationPermission) {
            val permissionsToRequest = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    // Configuración del estado de la cámara del mapa
    val initialLatLng = latestLocation?.let { LatLng(it.latitude, it.longitude) } ?: LatLng(0.0, 0.0)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initialLatLng, 15f)
    }

    // Animamos la cámara de forma fluida cada vez que ingresa un punto de localización GPS válido
    LaunchedEffect(latestLocation) {
        latestLocation?.let { loc ->
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLngZoom(LatLng(loc.latitude, loc.longitude), 16f)
            )
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (!hasLocationPermission) {
            // Estado vacío de permisos descriptivo y accesible (Material 3)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOff,
                        contentDescription = "Sin permiso de ubicación",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Permiso de Ubicación Requerido",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Para poder rastrear tus rutas en segundo plano de manera exacta y visualizar tu posición en tiempo real, activa los permisos de GPS de alta precisión.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            val permissions = mutableListOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(permissions.toTypedArray())
                        }
                    ) {
                        Text("Conceder Permisos")
                    }
                }
            }
        } else {
            // Renderizado Seguro de GoogleMaps
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                uiSettings = MapUiSettings(
                    zoomControlsEnabled = false,
                    myLocationButtonEnabled = true,
                    compassEnabled = true
                ),
                properties = MapProperties(
                    isMyLocationEnabled = true
                )
            ) {
                // Dibujar el camino trazado por el GPS
                if (routePoints.size > 1) {
                    Polyline(
                        points = routePoints.map { LatLng(it.latitude, it.longitude) },
                        color = MaterialTheme.colorScheme.primary,
                        width = 10f,
                        jointType = com.google.android.gms.maps.model.JointType.ROUND
                    )
                }

                // Dibujar ícono de inicio de ruta
                if (routePoints.isNotEmpty()) {
                    val startPoint = routePoints.first()
                    Marker(
                        state = rememberMarkerState(position = LatLng(startPoint.latitude, startPoint.longitude)),
                        title = "Inicio del recorrido",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                    )
                }

                // Dibujar Waypoints en el mapa como marcadores naranjas personalizados
                waypoints.forEach { wp ->
                    Marker(
                        state = rememberMarkerState(position = LatLng(wp.latitude, wp.longitude)),
                        title = wp.name,
                        snippet = wp.description,
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)
                    )
                }
            }

            // Panel de Control Flotante Superior: Estadísticas en vivo (High Density Theme)
            if (isTracking) {
                // Fila Superior con 2 Tarjetas Semitransparentes en Paralelo (High Density Grid Layout)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, start = 14.dp, end = 14.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Tarjeta 1: DISTANCIA
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White.copy(alpha = 0.90f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "DISTANCIA",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = String.format("%.2f km", distanceMeters / 1000.0),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Tarjeta 2: TIEMPO Elapso
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White.copy(alpha = 0.90f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "TIEMPO",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = formatElapsedTime(elapsedSeconds),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Panel Lateral de Estadísticas Secundarias (High Density Floating Sidebar)
                Column(
                    modifier = Modifier
                        .padding(top = 114.dp, end = 14.dp)
                        .align(Alignment.TopEnd),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    val speedKmh = latestLocation?.let { it.speed * 3.6f } ?: 0.0f
                    // Pill 1: Velocidad actual
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.90f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Velocidad",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = String.format("%.1f km/h", speedKmh),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Pill 2: Altitud/Relieve simulado u medido
                    val altitude = latestLocation?.let { if (it.hasAltitude()) it.altitude.toInt() else 142 } ?: 142
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.90f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terrain,
                                contentDescription = "Altitud",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "$altitude m",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Botón de Centrar Mapa (MyLocation Button) en la esquina inferior izquierda
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 32.dp, start = 16.dp)
            ) {
                IconButton(
                    onClick = {
                        latestLocation?.let { loc ->
                            coroutineScope.launch {
                                cameraPositionState.animate(
                                    CameraUpdateFactory.newLatLngZoom(LatLng(loc.latitude, loc.longitude), 16f)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White, shape = RoundedCornerShape(percent = 50))
                        .padding(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "Centrar ubicación",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Panel de Control Flotante Inferior: Botonera modular de rastreo
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 24.dp, end = 16.dp)
            ) {
                if (!isTracking) {
                    // Botón de Inicio Centrado
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .align(Alignment.BottomCenter),
                        contentAlignment = Alignment.Center
                    ) {
                        ExtendedFloatingActionButton(
                            onClick = {
                                newRouteName = "Ruta ${System.currentTimeMillis() % 10000}"
                                showStartDialog = true
                            },
                            icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Iniciar") },
                            text = { Text("Iniciar Grabación", fontWeight = FontWeight.Bold) },
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(56.dp)
                        )
                    }
                } else {
                    // Pilas de Acciones en Vertical a la derechas de la pantalla (según HTML de Alta Densidad)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Botón Añadir Punto de Interés (Waypoint)
                        FloatingActionButton(
                            onClick = { showWaypointDialog = true },
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddLocationAlt,
                                contentDescription = "Marcar Waypoint",
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Botón de Pausar temporalmente
                        FloatingActionButton(
                            onClick = { viewModel.pauseTrackingRoute(context) },
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pausar Tracking",
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Botón Detener y Guardar definitivo (Rojo)
                        FloatingActionButton(
                            onClick = { viewModel.stopTrackingRoute(context) },
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = Color.White,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Detener y Guardar",
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            // Si el rastreo está "en pausado" según el ViewModel de DB pero el LocationService no corre,
            // permitimos el prompt de reanudación
            val dbActiveRoute by viewModel.activeRouteInDb.collectAsState()
            if (dbActiveRoute != null && !isTracking) {
                dbActiveRoute?.let { activeRoute ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 110.dp, start = 24.dp, end = 24.dp)
                            .align(Alignment.BottomCenter),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ruta pausada: ${activeRoute.name}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "Puedes reanudar el rastreo o guardarlo definitivamente.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.resumeTrackingRoute(context, activeRoute.id, activeRoute.name)
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Reanudar", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Diálogo: Iniciar Grabación de Ruta ---
    if (showStartDialog) {
        AlertDialog(
            onDismissRequest = { showStartDialog = false },
            title = { Text("Nueva Ruta GPS") },
            text = {
                Column {
                    Text("Define un nombre para identificar este recorrido en tu historial:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newRouteName,
                        onValueChange = { newRouteName = it },
                        label = { Text("Nombre de la ruta") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newRouteName.isNotBlank()) {
                            viewModel.startTrackingRoute(context, newRouteName)
                            showStartDialog = false
                        }
                    }
                ) {
                    Text("Comenzar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStartDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // --- Diálogo: Añadir de Punto de Interés (Waypoint) ---
    if (showWaypointDialog) {
        AlertDialog(
            onDismissRequest = { showWaypointDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AddLocation, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Añadir Punto de Interés")
                }
            },
            text = {
                Column {
                    Text("Guarda una anotación útil en tus coordenadas actuales para consultarla en el mapa:", fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = waypointName,
                        onValueChange = { waypointName = it },
                        label = { Text("Nombre del punto") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = waypointDescription,
                        onValueChange = { waypointDescription = it },
                        label = { Text("Descripción (ej. Mirador, Refugio, Pozo)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (waypointName.isNotBlank()) {
                            viewModel.addWaypointToActiveRoute(waypointName, waypointDescription)
                            waypointName = ""
                            waypointDescription = ""
                            showWaypointDialog = false
                        }
                    }
                ) {
                    Text("Guardar Punto")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWaypointDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

/**
 * Formateador auxiliar del tiempo transcurrido en el servicio.
 */
private fun formatElapsedTime(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
