package com.example.ui

import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.LocationPoint
import com.example.data.model.Route
import com.example.data.model.Waypoint
import com.example.data.repository.RouteRepository
import com.example.location.LocationService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * Representa las pantallas disponibles de la aplicación para navegación reactiva de interfaz.
 */
sealed interface Screen {
    object Tracking : Screen
    object History : Screen
    data class Detail(val routeId: Int) : Screen
}

/**
 * ViewModel principal que orquesta la lógica de negocio, coordina acciones con el Foreground LocationService,
 * y maneja el estado de las vistas de Google Maps e Historial.
 */
class RouteViewModel(private val repository: RouteRepository) : ViewModel() {

    // Navegación en memoria simplificada y súper robusta
    var currentScreen by mutableStateOf<Screen>(Screen.Tracking)
        private set

    fun navigateTo(screen: Screen) {
        currentScreen = screen
    }

    // --- Flujos procedentes de la base de datos ---
    val allRoutes: StateFlow<List<Route>> = repository.allRoutes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeRouteInDb: StateFlow<Route?> = repository.activeRouteFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    // --- Estados procedentes directamente del Foreground Service ---
    val isTrackingLive: StateFlow<Boolean> = LocationService.isTracking
    val activeRouteIdLive: StateFlow<Int?> = LocationService.currentRouteId
    val latestLocationLive: StateFlow<Location?> = LocationService.latestLocation
    val elapsedSecondsLive: StateFlow<Long> = LocationService.elapsedTimeSeconds
    val distanceMetersLive: StateFlow<Double> = LocationService.currentDistanceMeters

    // Flujo dinámico de coordenadas en tiempo real de la ruta activa actualmente
    @OptIn(ExperimentalCoroutinesApi::class)
    val activeRoutePoints: StateFlow<List<LocationPoint>> = activeRouteIdLive
        .flatMapLatest { id ->
            if (id != null) {
                repository.getLocationPointsFlow(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Flujo de waypoints guardados para la ruta activa actualmente
    @OptIn(ExperimentalCoroutinesApi::class)
    val activeRouteWaypoints: StateFlow<List<Waypoint>> = activeRouteIdLive
        .flatMapLatest { id ->
            if (id != null) {
                repository.getWaypointsFlow(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Flujos para Visualización de Detalle de Rutas Antiguas ---
    private val _selectedDetailRouteId = MutableStateFlow<Int?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedDetailRoute: StateFlow<Route?> = _selectedDetailRouteId
        .flatMapLatest { id ->
            if (id != null) {
                repository.getRouteByIdFlow(id)
            } else {
                flowOf(null)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedDetailPoints: StateFlow<List<LocationPoint>> = _selectedDetailRouteId
        .flatMapLatest { id ->
            if (id != null) {
                repository.getLocationPointsFlow(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedDetailWaypoints: StateFlow<List<Waypoint>> = _selectedDetailRouteId
        .flatMapLatest { id ->
            if (id != null) {
                repository.getWaypointsFlow(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun selectRouteForDetail(routeId: Int) {
        _selectedDetailRouteId.value = routeId
        navigateTo(Screen.Detail(routeId))
    }

    // --- Operaciones de Control de Servicio y Datos ---

    /**
     * Inicia una nueva ruta con un nombre descriptivo en Room, y levanta el servicio en primer plano.
     */
    fun startTrackingRoute(context: Context, name: String) {
        viewModelScope.launch {
            val routeId = repository.startNewRoute(name)
            val intent = Intent(context, LocationService::class.java).apply {
                action = LocationService.ACTION_START
                putExtra(LocationService.EXTRA_ROUTE_NAME, name)
                putExtra(LocationService.EXTRA_ROUTE_ID, routeId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    /**
     * Reanuda la ruta activa si se pausó temporalmente el servicio.
     */
    fun resumeTrackingRoute(context: Context, routeId: Int, name: String) {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_START
            putExtra(LocationService.EXTRA_ROUTE_NAME, name)
            putExtra(LocationService.EXTRA_ROUTE_ID, routeId)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    /**
     * Pausa las actualizaciones de ubicación del GPS sin cerrar la sesión ni el contador de ruta.
     */
    fun pauseTrackingRoute(context: Context) {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_PAUSE
        }
        context.startService(intent)
    }

    /**
     * Finaliza de forma definitiva el registro de la ruta activa y para el servicio en primer plano.
     */
    fun stopTrackingRoute(context: Context) {
        val intent = Intent(context, LocationService::class.java).apply {
            action = LocationService.ACTION_STOP
        }
        context.startService(intent)
    }

    /**
     * Crea un Punto de Interés (Waypoint) en la localización actual de la ruta activa.
     */
    fun addWaypointToActiveRoute(name: String, description: String) {
        val routeId = activeRouteIdLive.value ?: return
        val location = latestLocationLive.value

        viewModelScope.launch {
            if (location != null) {
                repository.addWaypoint(
                    routeId = routeId,
                    name = name,
                    description = description,
                    latitude = location.latitude,
                    longitude = location.longitude
                )
            } else {
                // Si no hay señal GPS instantánea en el live, intentamos usar el último nodo grabado
                val points = repository.getLocationPointsSync(routeId)
                if (points.isNotEmpty()) {
                    val fallbackNode = points.last()
                    repository.addWaypoint(
                        routeId = routeId,
                        name = name,
                        description = description,
                        latitude = fallbackNode.latitude,
                        longitude = fallbackNode.longitude
                    )
                }
            }
        }
    }

    /**
     * Elimina una ruta guardada (por cascada borrará todos sus puntos GPS y waypoints).
     */
    fun deleteRoute(routeId: Int) {
        viewModelScope.launch {
            repository.deleteRoute(routeId)
        }
    }
}

/**
 * Factory para la instanciación de RouteViewModel con su respectivo repositorio.
 */
class RouteViewModelFactory(private val repository: RouteRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RouteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RouteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
