package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocationPoint
import com.example.data.model.Route
import com.example.data.model.Waypoint
import com.example.ui.RouteViewModel
import com.example.ui.Screen
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Pantalla de Detalle de Ruta.
 * Dibuja la ruta guardada completa en el mapa estático con cálculo automático de encuadre en pantalla (Bounds).
 * Permite navegar horizontalmente entre los Waypoints registrados para hacer zoom automático en sus ubicaciones.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    viewModel: RouteViewModel,
    routeId: Int,
    modifier: Modifier = Modifier
) {
    val route by viewModel.selectedDetailRoute.collectAsState()
    val points by viewModel.selectedDetailPoints.collectAsState()
    val waypoints by viewModel.selectedDetailWaypoints.collectAsState()

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(0.0, 0.0), 10f)
    }

    // Centrar automáticamente la cámara del mapa abarcando todas las coordinadas de la ruta
    LaunchedEffect(points) {
        if (points.isNotEmpty()) {
            val boundsBuilder = LatLngBounds.builder()
            points.forEach { pt ->
                boundsBuilder.include(LatLng(pt.latitude, pt.longitude))
            }
            try {
                val bounds = boundsBuilder.build()
                // Animamos a los márgenes ideales de pantalla (padding de 120px)
                cameraPositionState.animate(
                    CameraUpdateFactory.newLatLngBounds(bounds, 120),
                    1000
                )
            } catch (ignored: Exception) {
                // Manejo de contingencia para rutas de nodo único (e.g. parada inmediata)
                val coord = LatLng(points.first().latitude, points.first().longitude)
                cameraPositionState.animate(
                    CameraUpdateFactory.newLatLngZoom(coord, 16f)
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(route?.name ?: "Detalle del Recorrido", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.History) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver al historial"
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (points.isEmpty()) {
                // Pantalla de carga interactiva si está leyendo de base de datos
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Cargando coordenadas GPS...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                // Google Map estático con polilíneas sólidas y marcadores identificadores
                GoogleMap(
                    modifier = Modifier.fillMaxSize(),
                    cameraPositionState = cameraPositionState,
                    uiSettings = MapUiSettings(
                        zoomControlsEnabled = true,
                        myLocationButtonEnabled = false,
                        compassEnabled = true
                    )
                ) {
                    // Trazar línea completa del recorrido
                    Polyline(
                        points = points.map { LatLng(it.latitude, it.longitude) },
                        color = MaterialTheme.colorScheme.primary,
                        width = 8f,
                        jointType = com.google.android.gms.maps.model.JointType.ROUND
                    )

                    // Marcador PIN Verde para marcar la coordenada de inicio
                    val first = points.first()
                    Marker(
                        state = rememberMarkerState(position = LatLng(first.latitude, first.longitude)),
                        title = "Inicio del trayecto",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                    )

                    // Marcador PIN Rojo para marcar la coordenada de finalización
                    val last = points.last()
                    Marker(
                        state = rememberMarkerState(position = LatLng(last.latitude, last.longitude)),
                        title = "Fin del trayecto",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)
                    )

                    // Waypoints personalizados
                    waypoints.forEach { wp ->
                        Marker(
                            state = rememberMarkerState(position = LatLng(wp.latitude, wp.longitude)),
                            title = wp.name,
                            snippet = wp.description,
                            icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)
                        )
                    }
                }

                // Panel Superior: Estadísticas acumuladas duraderas y promedio de velocidad
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp, start = 12.dp, end = 12.dp)
                        .align(Alignment.TopCenter),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            // Fila 1: Distancia y Duración
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                val km = (route?.distanceMeters ?: 0.0) / 1000.0
                                val durationMillis = if ((route?.endTime ?: 0) > (route?.startTime ?: 0)) {
                                    route!!.endTime - route!!.startTime
                                } else 0L

                                DetailStatItem(
                                    icon = Icons.Default.TrendingUp,
                                    title = "Distancia",
                                    value = String.format("%.2f km", km),
                                    tint = MaterialTheme.colorScheme.primary
                                )

                                DetailStatItem(
                                    icon = Icons.Default.Schedule,
                                    title = "Duración",
                                    value = formatDuration(durationMillis),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Fila 2: Velocidades y Altitudes
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                // Promedio de velocidades registradas si hay datos disponibles
                                val validSpeeds = points.map { it.speed }.filter { it > 0f }
                                val avgSpeed = if (validSpeeds.isNotEmpty()) {
                                    validSpeeds.average() * 3.6
                                } else {
                                    // Fallback aritmético si las coordenadas de satélites no midieron speeds individuales
                                    val durationSeconds = if ((route?.endTime ?: 0) > (route?.startTime ?: 0)) {
                                        (route!!.endTime - route!!.startTime) / 1000.0
                                    } else 0.0
                                    if (durationSeconds > 0) ((route?.distanceMeters ?: 0.0) / durationSeconds) * 3.6 else 0.0
                                }

                                val altitudes = points.map { it.altitude }
                                val maxAltitude = if (altitudes.isNotEmpty()) altitudes.maxOrNull() ?: 0.0 else 0.0

                                DetailStatItem(
                                    icon = Icons.Default.Speed,
                                    title = "Vel. Promedio",
                                    value = String.format("%.1f km/h", avgSpeed),
                                    tint = MaterialTheme.colorScheme.secondary
                                )

                                DetailStatItem(
                                    icon = Icons.Default.FilterHdr,
                                    title = "Altitud Máxima",
                                    value = String.format("%.0fm", maxAltitude),
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }
                }

                // Panel Inferior: Carrusel deslizante de Waypoints (POIs) marcados
                if (waypoints.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(waypoints) { wp ->
                                Card(
                                    modifier = Modifier
                                        .width(220.dp)
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    onClick = {
                                        // Efectuamos scroll o zoom suave directamente sobre el Mark del waypoint tapped
                                        cameraPositionState.position = CameraPosition.fromLatLngZoom(
                                            LatLng(wp.latitude, wp.longitude), 18f
                                        )
                                    }
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Place,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = wp.name,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                maxLines = 1
                                            )
                                        }
                                        if (wp.description.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = wp.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 11.sp,
                                                maxLines = 2
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailStatItem(
    icon: ImageVector,
    title: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun formatDuration(millis: Long): String {
    if (millis <= 0) return "00:00:00"
    val h = TimeUnit.MILLISECONDS.toHours(millis)
    val m = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
    val s = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
